USE Smekciu;
DROP TABLE rating;
DROP TABLE appointment;
DROP TABLE payment;
DROP TABLE client;
DROP TABLE employee;
DROP TABLE service;