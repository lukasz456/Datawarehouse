-- Create Service table
CREATE DATABASE Smekciu;
USE Smekciu;
CREATE TABLE service (
    service_id INT PRIMARY KEY,
    name VARCHAR(100),
    price DECIMAL(10, 2),
    is_actual CHAR(5)
);

CREATE TABLE employee (
    employee_id INT PRIMARY KEY,
    name VARCHAR(100),
    surname VARCHAR(100),
    gender CHAR(1),
    date_of_birth DATE
);

-- Create Client table
CREATE TABLE client (
    client_id INT PRIMARY KEY,
    name VARCHAR(100),
    surname VARCHAR(100),
    phone_number VARCHAR(20)
);

-- Create Payment table
CREATE TABLE payment (
    payment_id INT PRIMARY KEY,
    method VARCHAR(100),
    amount DECIMAL(10, 2)
);

CREATE TABLE appointment (
    appointment_id INT PRIMARY KEY,
    date DATE,
    hour VARCHAR(10),
    status VARCHAR(50),
	service_id INT NOT NULL REFERENCES service,
	client_id INT NOT NULL REFERENCES client,
	employee_id INT NOT NULL REFERENCES employee,
	payment_id INT REFERENCES payment
);

-- Create Rating table
CREATE TABLE rating (
    rating_id INT PRIMARY KEY,
    points INT,
    position VARCHAR(100),
	appointment_id INT,
	FOREIGN KEY (appointment_id) REFERENCES appointment(appointment_id)
);

USE Smekciu
SELECT *
FROM appointment AS a

JOIN payment AS p
ON a.payment_id = p.payment_id
JOIN service AS s
ON a.service_id = s.service_id

SELECT *
FROM appointment AS a
JOIN rating AS r
ON a.appointment_id = r.appointment_id
LEFT JOIN client AS c
ON a.client_id = c.client_id;

USE Smekciu
SELECT *
FROM Date

SELECT *
FROM rating

SELECT *
FROM client

SELECT *
FROM payment

SELECT *
FROM rating

SELECT *
FROM service
