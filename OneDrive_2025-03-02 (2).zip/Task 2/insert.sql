-- 1 snapshot
USE Smekciu;
BULK INSERT service FROM 'C:\Users\badyl\OneDrive\Pulpit\projekty studia\4 semestr\Data Warehouses\Task 2\service_bulk_1.csv' WITH (FIELDTERMINATOR=',');
BULK INSERT employee FROM 'C:\Users\badyl\OneDrive\Pulpit\projekty studia\4 semestr\Data Warehouses\Task 2\employee_bulk_1.csv' WITH (FIELDTERMINATOR=',');
BULK INSERT client FROM 'C:\Users\badyl\OneDrive\Pulpit\projekty studia\4 semestr\Data Warehouses\Task 2\client_bulk_1.csv' WITH (FIELDTERMINATOR=',');
BULK INSERT payment FROM 'C:\Users\badyl\OneDrive\Pulpit\projekty studia\4 semestr\Data Warehouses\Task 2\payment_bulk_1.csv' WITH (FIELDTERMINATOR=',');
BULK INSERT appointment FROM 'C:\Users\badyl\OneDrive\Pulpit\projekty studia\4 semestr\Data Warehouses\Task 2\appointment_bulk_1.csv' WITH (FIELDTERMINATOR=',');
BULK INSERT rating FROM 'C:\Users\badyl\OneDrive\Pulpit\projekty studia\4 semestr\Data Warehouses\Task 2\rating_bulk_1.csv' WITH (FIELDTERMINATOR=',');

-- 2 snapshot
USE Smekciu;
BULK INSERT service FROM 'C:\Users\badyl\OneDrive\Pulpit\projekty studia\4 semestr\Data Warehouses\Task 2\service_bulk_2.csv' WITH (FIELDTERMINATOR=',');
BULK INSERT employee FROM 'C:\Users\badyl\OneDrive\Pulpit\projekty studia\4 semestr\Data Warehouses\Task 2\employee_bulk_2.csv' WITH (FIELDTERMINATOR=',');
BULK INSERT client FROM 'C:\Users\badyl\OneDrive\Pulpit\data_generator\clients.csv' WITH (FIELDTERMINATOR=',');
BULK INSERT payment FROM 'C:\Users\badyl\OneDrive\Pulpit\data_generator\payments.csv' WITH (FIELDTERMINATOR=',');
BULK INSERT appointment FROM 'C:\Users\badyl\OneDrive\Pulpit\data_generator\appointments.csv' WITH (FIELDTERMINATOR=',');
BULK INSERT rating FROM 'C:\Users\badyl\OneDrive\Pulpit\data_generator\ratings.csv' WITH (FIELDTERMINATOR=',');


